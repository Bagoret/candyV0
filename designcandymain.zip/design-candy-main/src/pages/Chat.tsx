import { SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/AppSidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, Mic } from "lucide-react"

const Chat = () => {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <main className="flex-1 overflow-y-auto p-6 flex flex-col">
          <h1 className="text-4xl font-bold mb-6 hero-gradient">
            Interact with lifelike AI personalities in real-time.
          </h1>

          <div className="flex-1 bg-muted rounded-lg p-4 mb-4 overflow-y-auto">
            {/* Placeholder for chat messages */}
            <div className="space-y-4">
              <div className="bg-background p-3 rounded-lg max-w-[80%]">
                <p className="text-sm">Hello! How can I assist you today?</p>
              </div>
              <div className="bg-primary p-3 rounded-lg max-w-[80%] ml-auto">
                <p className="text-sm text-primary-foreground">Hi! I'd like to know more about AI companions.</p>
              </div>
              {/* Add more placeholder messages as needed */}
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Input type="text" placeholder="Type your message..." className="flex-1" />
            <Button size="icon">
              <Mic className="h-4 w-4" />
            </Button>
            <Button>
              <Send className="mr-2 h-4 w-4" /> Send
            </Button>
          </div>
        </main>
      </div>
    </SidebarProvider>
  )
}

export default Chat

