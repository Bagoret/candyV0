import { SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/AppSidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Filter } from "lucide-react"

const Explore = () => {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <main className="flex-1 overflow-y-auto p-6">
          <h1 className="text-4xl font-bold mb-6 hero-gradient">
            Discover AI-powered conversations, worlds, and characters.
          </h1>

          <div className="flex items-center space-x-4 mb-8">
            <div className="relative flex-1">
              <Input type="text" placeholder="Search for styles, genres, or personalities" className="pl-10" />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            </div>
            <Button variant="outline">
              <Filter className="mr-2 h-4 w-4" /> Filters
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Placeholder for AI-generated content */}
            {[...Array(9)].map((_, index) => (
              <div
                key={index}
                className="aspect-square bg-muted rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-300"
              >
                <img
                  src={`https://picsum.photos/seed/${index}/400/400`}
                  alt="AI-generated content"
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>

          <div className="mt-8 text-center">
            <Button size="lg">Load More</Button>
          </div>
        </main>
      </div>
    </SidebarProvider>
  )
}

export default Explore

