import { SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/AppSidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"

const CreateCharacter = () => {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <main className="flex-1 overflow-y-auto p-6">
          <h1 className="text-4xl font-bold mb-6 hero-gradient">Bring your fantasy character to life with AI.</h1>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <Label htmlFor="name">Character Name</Label>
                <Input id="name" placeholder="Enter character name" />
              </div>
              <div>
                <Label htmlFor="backstory">Backstory</Label>
                <Textarea id="backstory" placeholder="Write your character's backstory..." />
              </div>
              <div>
                <Label>Personality Traits</Label>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="kindness">Kindness</Label>
                    <Slider id="kindness" min={0} max={100} step={1} />
                  </div>
                  <div>
                    <Label htmlFor="humor">Humor</Label>
                    <Slider id="humor" min={0} max={100} step={1} />
                  </div>
                  <div>
                    <Label htmlFor="intelligence">Intelligence</Label>
                    <Slider id="intelligence" min={0} max={100} step={1} />
                  </div>
                </div>
              </div>
              <Button className="w-full">Create Character</Button>
            </div>
            <div className="bg-muted aspect-square rounded-lg flex items-center justify-center">
              <p className="text-muted-foreground">Your character's avatar will appear here</p>
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  )
}

export default CreateCharacter

