import { SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/AppSidebar"
import { CharacterCard } from "@/components/CharacterCard"
import { FAQ } from "@/components/FAQ"
import { Testimonials } from "@/components/Testimonials"
import { Features } from "@/components/Features"
import { HeroSection } from "@/components/HeroSection"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { Link } from "react-router-dom"

const characters = [
  {
    name: "Luna",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2",
    description: "Empathetic and creative companion",
    personality: "Artistic • Supportive • Imaginative",
  },
  {
    name: "Kai",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d",
    description: "Intellectual discussion partner",
    personality: "Analytical • Curious • Witty",
  },
  {
    name: "Yuki",
    image: "https://images.unsplash.com/photo-1517841905240-472988babdf9",
    description: "Anime-inspired friend",
    personality: "Cheerful • Energetic • Caring",
  },
  {
    name: "Alex",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
    description: "Your personal life coach",
    personality: "Motivating • Understanding • Wise",
  },
  {
    name: "Sofia",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb",
    description: "Multilingual cultural guide",
    personality: "Cultured • Patient • Adventurous",
  },
  {
    name: "Neo",
    image: "https://images.unsplash.com/photo-1501196354995-cbb51c65aaea",
    description: "Tech-savvy mentor",
    personality: "Innovative • Logical • Helpful",
  },
]

const Index = () => {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <main className="flex-1 overflow-y-auto">
          <HeroSection />

          <div className="max-w-6xl mx-auto p-6 lg:p-8 space-y-24">
            {/* Character Cards */}
            <section>
              <h2 className="text-3xl font-bold mb-6 hero-gradient">Popular AI Companions</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {characters.map((character) => (
                  <CharacterCard
                    key={character.name}
                    name={character.name}
                    image={character.image}
                    description={character.description}
                    personality={character.personality}
                  />
                ))}
              </div>
              <div className="mt-8 text-center">
                <Button asChild>
                  <Link to="/explore" className="group">
                    Explore More
                    <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
              </div>
            </section>

            {/* Features Section */}
            <section className="glass-panel rounded-2xl p-12">
              <Features />
            </section>

            {/* Testimonials Section */}
            <section className="glass-panel rounded-2xl p-12">
              <Testimonials />
            </section>

            {/* FAQ Section */}
            <section className="glass-panel rounded-2xl p-12">
              <FAQ />
            </section>
          </div>
        </main>
      </div>
    </SidebarProvider>
  )
}

export default Index

