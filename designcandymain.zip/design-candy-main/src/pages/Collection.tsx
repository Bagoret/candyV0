import { SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/AppSidebar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageCircle, Image, User } from "lucide-react"

const Collection = () => {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <main className="flex-1 overflow-y-auto p-6">
          <h1 className="text-4xl font-bold mb-6 hero-gradient">
            Save, revisit, and share your favorite AI-generated moments.
          </h1>

          <Tabs defaultValue="chats" className="w-full">
            <TabsList>
              <TabsTrigger value="chats">
                <MessageCircle className="mr-2 h-4 w-4" /> Chats
              </TabsTrigger>
              <TabsTrigger value="images">
                <Image className="mr-2 h-4 w-4" /> Images
              </TabsTrigger>
              <TabsTrigger value="characters">
                <User className="mr-2 h-4 w-4" /> Characters
              </TabsTrigger>
            </TabsList>
            <TabsContent value="chats">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
                {/* Placeholder for saved chats */}
                {[...Array(6)].map((_, index) => (
                  <div key={index} className="bg-muted p-4 rounded-lg">
                    <h3 className="font-semibold mb-2">Chat #{index + 1}</h3>
                    <p className="text-sm text-muted-foreground mb-4">Last message: Hello, how are you?</p>
                    <Button variant="outline" size="sm">
                      View Chat
                    </Button>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="images">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-6">
                {/* Placeholder for saved images */}
                {[...Array(8)].map((_, index) => (
                  <div key={index} className="aspect-square bg-muted rounded-lg overflow-hidden">
                    <img
                      src={`https://picsum.photos/seed/${index + 10}/400/400`}
                      alt="Saved AI-generated image"
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="characters">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
                {/* Placeholder for saved characters */}
                {[...Array(6)].map((_, index) => (
                  <div key={index} className="bg-muted p-4 rounded-lg flex items-center space-x-4">
                    <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-2xl font-bold text-primary-foreground">
                      {String.fromCharCode(65 + index)}
                    </div>
                    <div>
                      <h3 className="font-semibold">Character {index + 1}</h3>
                      <p className="text-sm text-muted-foreground">Personality type</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </SidebarProvider>
  )
}

export default Collection

