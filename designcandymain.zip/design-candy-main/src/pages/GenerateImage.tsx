import { SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/AppSidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Wand2 } from "lucide-react"

const GenerateImage = () => {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar />
        <main className="flex-1 overflow-y-auto p-6">
          <h1 className="text-4xl font-bold mb-6 hero-gradient">Turn text into stunning AI-generated visuals.</h1>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-4">
              <Input type="text" placeholder="Enter your image description..." />
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Choose art style" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="realistic">Realistic</SelectItem>
                  <SelectItem value="anime">Anime</SelectItem>
                  <SelectItem value="cyberpunk">Cyberpunk</SelectItem>
                  <SelectItem value="fantasy">Fantasy</SelectItem>
                </SelectContent>
              </Select>
              <Button className="w-full">
                <Wand2 className="mr-2 h-4 w-4" /> Generate Image
              </Button>
            </div>
            <div className="bg-muted aspect-square rounded-lg flex items-center justify-center">
              <p className="text-muted-foreground">Your generated image will appear here</p>
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  )
}

export default GenerateImage

