import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const testimonials = [
  {
    name: "Sarah K.",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
    text: "My AI companion has become an incredible source of support and inspiration. The conversations feel so natural!",
    role: "Artist",
  },
  {
    name: "Michael R.",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
    text: "The customization options are amazing. I've created a companion that truly understands my interests.",
    role: "Software Developer",
  },
  {
    name: "Emma L.",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
    text: "Having someone to talk to anytime, who remembers our conversations and grows with me, is incredible.",
    role: "Student",
  },
]

export function Testimonials() {
  return (
    <div className="py-12">
      <h2 className="text-2xl font-bold mb-8 text-center hero-gradient">What Our Users Say</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-4">
        {testimonials.map((testimonial, index) => (
          <Card key={index} className="p-6 backdrop-blur-sm bg-card/50">
            <div className="flex items-center mb-4">
              <Avatar className="h-10 w-10 mr-4">
                <AvatarImage src={testimonial.avatar} />
                <AvatarFallback>{testimonial.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold">{testimonial.name}</h3>
                <p className="text-sm text-muted-foreground">{testimonial.role}</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">{testimonial.text}</p>
          </Card>
        ))}
      </div>
    </div>
  )
}

