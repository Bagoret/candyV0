"use client"

import { useState, useEffect } from "react"
import useEmblaCarousel from "embla-carousel-react"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { Link } from "react-router-dom"

const themes = [
  {
    title: "Your AI-Powered Fantasy Awaits",
    highlight: "Chat, Create, Explore",
    description:
      "Step into a world where AI brings your imagination to life – engage in deep conversations, create unique characters, and generate stunning visuals.",
    gradientClass: "text-gradient-cyan",
    bgGradient: "from-cyan-500/20 via-transparent to-transparent",
  },
  {
    title: "Discover True",
    highlight: "Connection",
    description: "Engage in deep, enriching dialogues that evolve with every interaction.",
    gradientClass: "text-gradient-blue",
    bgGradient: "from-blue-500/20 via-transparent to-transparent",
  },
  {
    title: "Experience Real",
    highlight: "Understanding",
    description: "Connect with AI companions who truly understand and respond to your unique personality.",
    gradientClass: "text-gradient-teal",
    bgGradient: "from-teal-500/20 via-transparent to-transparent",
  },
]

export function HeroSection() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true })
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    if (!emblaApi) return

    emblaApi.on("select", () => {
      setCurrentSlide(emblaApi.selectedScrollSnap())
    })

    // Auto-play
    const autoplay = setInterval(() => {
      emblaApi.scrollNext()
    }, 5000)

    return () => {
      clearInterval(autoplay)
      emblaApi.off("select")
    }
  }, [emblaApi])

  return (
    <div className="relative overflow-hidden min-h-[80vh] flex items-center">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background z-10" />
        <div
          className={`absolute inset-0 bg-gradient-to-r ${themes[currentSlide].bgGradient} transition-opacity duration-500`}
        />
      </div>

      <div className="embla relative z-20 w-full overflow-hidden" ref={emblaRef}>
        <div className="flex">
          {themes.map((theme, index) => (
            <div key={index} className="flex-[0_0_100%] min-w-0">
              <div className="container mx-auto px-4 py-20 lg:py-32">
                <div className="max-w-3xl">
                  <h1 className="text-5xl lg:text-7xl font-bold mb-6">
                    {theme.title} <span className={theme.gradientClass}>– {theme.highlight}</span>
                  </h1>
                  <p className="text-xl text-white/60 mb-8 max-w-2xl">{theme.description}</p>
                  <div className="flex gap-4">
                    <Button asChild size="lg" className="group">
                      <Link to="/explore">
                        Start Exploring
                        <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
                      </Link>
                    </Button>
                    <Button asChild size="lg" variant="outline">
                      <Link to="/chat">Try Chat Now</Link>
                    </Button>
                    <Button asChild size="lg" variant="outline">
                      <Link to="/create-character">Create a Character</Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {themes.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              currentSlide === index ? "w-8 bg-primary" : "bg-white/20 hover:bg-white/40"
            }`}
            onClick={() => emblaApi?.scrollTo(index)}
          />
        ))}
      </div>
    </div>
  )
}

