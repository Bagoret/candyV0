import { Compass, MessageCircle, Image, Wand2, Heart, Crown } from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { Link } from "react-router-dom"

const menuItems = [
  { title: "Explore", icon: Compass, url: "/explore" },
  { title: "Chat", icon: MessageCircle, url: "/chat" },
  { title: "Collection", icon: Heart, url: "/collection" },
  { title: "Generate Image", icon: Image, url: "/generate-image" },
  { title: "Create Character", icon: Wand2, url: "/create-character" },
  { title: "Become Premium", icon: Crown, url: "/become-premium", isPremium: true },
]

export function AppSidebar() {
  return (
    <>
      <Sidebar>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                {menuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <Link to={item.url} className={`flex items-center gap-2 ${item.isPremium ? "text-primary" : ""}`}>
                        <item.icon className="h-5 w-5" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
      </Sidebar>
    </>
  )
}

