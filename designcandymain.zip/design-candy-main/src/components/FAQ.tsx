import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "How does an AI companion work?",
    answer:
      "Our AI companions use advanced natural language processing to engage in meaningful conversations, learn from interactions, and provide companionship tailored to your preferences.",
  },
  {
    question: "Can I customize my AI companion's personality?",
    answer:
      "Yes! You can customize various aspects of your AI companion's personality, interests, and conversation style to create a unique experience that resonates with you.",
  },
  {
    question: "Is my privacy protected?",
    answer:
      "We take privacy seriously. All conversations are encrypted, and personal data is handled according to strict security protocols. Your information is never shared without consent.",
  },
  {
    question: "How realistic are the conversations?",
    answer:
      "Our AI companions use state-of-the-art language models to create natural, context-aware conversations that feel genuine and engaging.",
  },
  {
    question: "Can I have multiple AI companions?",
    answer:
      "Yes, you can create and interact with multiple AI companions, each with their own unique personality and conversation style.",
  },
  {
    question: "What languages are supported?",
    answer:
      "Our AI companions currently support multiple languages including English, Spanish, French, German, and Japanese, with more languages being added regularly.",
  },
]

export function FAQ() {
  return (
    <div className="w-full max-w-3xl mx-auto px-4">
      <h2 className="text-2xl font-bold mb-6 hero-gradient">Frequently Asked Questions</h2>
      <Accordion type="single" collapsible className="w-full">
        {faqs.map((faq, index) => (
          <AccordionItem key={index} value={`item-${index}`}>
            <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
            <AccordionContent>{faq.answer}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  )
}

