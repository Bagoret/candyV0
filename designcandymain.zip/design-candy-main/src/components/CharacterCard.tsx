import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MessageCircle } from "lucide-react"

interface CharacterCardProps {
  name: string
  image: string
  description: string
  personality?: string
}

export function CharacterCard({ name, image, description, personality }: CharacterCardProps) {
  return (
    <Card className="relative overflow-hidden card-hover group">
      <div className="aspect-[3/4] overflow-hidden">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/90" />
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-6 transform transition-transform duration-300">
        <h3 className="text-xl font-semibold mb-2 text-white/90">{name}</h3>
        <p className="text-sm text-white/70 mb-3 line-clamp-2">{description}</p>
        {personality && <p className="text-xs text-white/60 mb-4">{personality}</p>}
        <Button
          className="w-full bg-white/10 backdrop-blur-sm hover:bg-white/20 transition-all duration-300"
          variant="secondary"
        >
          <MessageCircle className="w-4 h-4 mr-2" />
          Chat Now
        </Button>
      </div>
    </Card>
  )
}

