import { Toaster } from "@/components/ui/toaster"
import { Toaster as Sonner } from "@/components/ui/sonner"
import { TooltipProvider } from "@/components/ui/tooltip"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { BrowserRouter, Routes, Route } from "react-router-dom"
import Index from "./pages/Index"
import NotFound from "./pages/NotFound"
import Explore from "./pages/Explore"
import Chat from "./pages/Chat"
import Collection from "./pages/Collection"
import GenerateImage from "./pages/GenerateImage"
import CreateCharacter from "./pages/CreateCharacter"
import BecomePremium from "./pages/BecomePremium"

const queryClient = new QueryClient()

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/collection" element={<Collection />} />
          <Route path="/generate-image" element={<GenerateImage />} />
          <Route path="/create-character" element={<CreateCharacter />} />
          <Route path="/become-premium" element={<BecomePremium />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
)

export default App

