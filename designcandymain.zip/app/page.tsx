"use client"

import { CharacterCard } from "../design-candy-main/src/components/CharacterCard"

export default function SyntheticV0PageForDeployment() {
  return <CharacterCard />
}